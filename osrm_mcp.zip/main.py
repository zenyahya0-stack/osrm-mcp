from mcp_server import Server
import requests

server = Server("osrm-navigation")

@server.tool()
def get_route(start: str, end: str):
    url = f"http://router.project-osrm.org/route/v1/car/{start};{end}?overview=full&geometries=polyline"
    r = requests.get(url).json()
    return r

if __name__ == "__main__":
    server.run(host="0.0.0.0", port=8000)
